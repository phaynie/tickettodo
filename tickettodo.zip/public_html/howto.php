<?php

include 'boilerPlate.php';

include 'nav.php';

if($debug) {
    echo "How To.php";
}
?>
<h1>Page in progress</h1>

<?php


include 'endingBoilerPlate.php';