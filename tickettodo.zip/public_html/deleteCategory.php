<?php
include 'boilerPlate.php';

//include 'nav.php';

if($debug) {
    echo "INDEX.php";
}
